setwd("~/Desktop/RA/Task 5- Introducing to IBD/")
# I selected metagenomics data!
# HMP2
# While Metagenomics tells us which microbes are present 
# and what genomic potential they have, Metatranscriptomics tells us about their activity
# I use taxonomic profiles that is cleaned and treamed and QCd!

# 16s rRNA is a fingerprint for each bacteria

## Plot krona chart
library(highcharter)
library(readr)
library(matrixStats)
library(gridExtra)
library(ggplot2)
source("utility.R")
# tab-separated 
metagenome.tax.data <- read_tsv("Data/Metagenomics/taxonomic_profiles.tsv.gz")

methmp <- read_csv("Data/hmp2_metadata.csv")

##### Create tax table and otu table 
library(stringr)
library(dplyr)
metagenome.tax.data$`#SampleID` %>% 
  str_count(pattern = "\\|") %>% hist(main = "Histogram of microbes in different ranks")

metagenome.tax.data %>% 
  filter(str_count(`#SampleID` , "\\|") == 7) -> tmp8
metagenome.tax.data %>% 
  filter(str_count(`#SampleID` , "\\|") == 6) -> tmp7
metagenome.tax.data %>% 
  filter(str_count(`#SampleID` , "\\|") == 5) -> tmp6
metagenome.tax.data %>% 
  filter(str_count(`#SampleID` , "\\|") == 4) -> tmp5
metagenome.tax.data %>% 
  filter(str_count(`#SampleID` , "\\|") == 3) -> tmp4

library(tidyr)
library(rlist)
taxas.analysis <- vector(mode = "list")
taxa.ranks <- c("Kingdom" , "Phylum" , "Class" , "Order" , "Family" , "Genus" , "Species" , "Strain")

### PROBLEM : PASS BY REFERENCE
taxas.analysis[[1]] <- analyzeTaxRank.zeros(tmp4 , 4)
taxas.analysis[[2]] <- analyzeTaxRank.zeros(tmp5 , 5)
taxas.analysis[[3]] <- analyzeTaxRank.zeros(tmp6 , 6)
taxas.analysis[[4]] <- analyzeTaxRank.zeros(tmp7 , 7)
taxas.analysis[[5]] <- analyzeTaxRank.zeros(tmp8 , 8)

taxa.ranks.summary <-  bind_rows(taxas.analysis)

tmp <- gather(taxa.ranks.summary)
tmp$ranks <- rep(taxa.ranks[4:8] , 4)
hchart(tmp , "column" , hcaes(x = key , y = value , group = ranks))
# External ID is a marker 

# A function to summarize some statistics about the data
# This function extracts :
# Sum , Variance , IQR , Median , Max
sum.tmp4 <- analyzeTaxRank.counts(tmp4 , 4)
sum.tmp5 <- analyzeTaxRank.counts(tmp5 , 5)
sum.tmp6 <- analyzeTaxRank.counts(tmp6 , 6)
sum.tmp7 <- analyzeTaxRank.counts(tmp7 , 7)
sum.tmp8 <- analyzeTaxRank.counts(tmp8 , 8)

p1 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = sumOfCounts)) + xlab("Sum of counts") + ylab(taxa.ranks[4])
p2 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = sumOfVars)) + xlab("Variance of counts") + ylab(taxa.ranks[4])

p3 <- ggplot(sum.tmp5) + 
  geom_density(aes(x = sumOfCounts)) + xlab("Sum of counts") + ylab(taxa.ranks[5])
p4 <- ggplot(sum.tmp5) + 
  geom_density(aes(x = sumOfVars)) + xlab("Variance of counts") + ylab(taxa.ranks[5])

p5 <- ggplot(sum.tmp6) + 
  geom_density(aes(x = sumOfCounts)) + xlab("Sum of counts") + ylab(taxa.ranks[6])
p6 <- ggplot(sum.tmp6) + 
  geom_density(aes(x = sumOfVars)) + xlab("Variance of counts") + ylab(taxa.ranks[6])

p7 <- ggplot(sum.tmp7) + 
  geom_density(aes(x = sumOfCounts)) + xlab("Sum of counts") + ylab(taxa.ranks[7]) 
p8 <- ggplot(sum.tmp7) + 
  geom_density(aes(x = sumOfVars)) + xlab("Variance of counts") + ylab(taxa.ranks[7])

p9 <- ggplot(sum.tmp8) + 
  geom_density(aes(x = sumOfCounts)) + xlab("Sum of counts") + ylab(taxa.ranks[8])
p10 <- ggplot(sum.tmp8) + 
  geom_density(aes(x = sumOfVars)) + xlab("Variance of counts") + ylab(taxa.ranks[8])
pdf("./Plots/Sum-Variance.pdf")
grid.arrange(ncol = 2 , p1 , p2 , p3, p4, p5, p6, p7, p8 , p9, p10)
dev.off()
png("./Plots/sum-variance.png")
grid.arrange(ncol = 2 , p1 , p2 , p3, p4, p5, p6, p7, p8 , p9, p10)
dev.off()

pdf("./Plots/IQR-Median-Max.pdf")

#############
# Make the data better!
dataset <- as.data.frame(metagenome.tax.data)
rownames(dataset) <- metagenome.tax.data$`#SampleID`
dataset <- dataset[-1 , ]

#########
# Import the data intro phyloseq object using 
library(phyloseq)

metagenom-e.biom <- import_biom("Data/Metagenomics/taxonomic_profiles.biom.gz")
tax = matrix(rownames(otu_table(metagenome.biom)))
tax %>% 
  str_count(pattern  = "\\|") -> tax.summary
hist(tax.summary , breaks = 7)
dim(tax)


OTU <- otu_table()
rownames(tax) <- as.matrix(tax)
tmp <- rownames(tax)
tmp <- strsplit(tmp , split = "|")

myData <- import_biom(BIOMfilename = "Data/Metagenomics/taxonomic_profiles.biom.gz" , parseFunction = parse_taxonomy_greengenes)

data.phy <- phyloseq(otu_table(metagenome.biom) , tax_table(tax))
data.phy

remove(metagenome.biom)

#########

library(dplyr)
library(ggplot2)
pheno.selected <- methmp %>% 
  select(sampleID = `External ID` , diagnosis , sex , race , `Were you born prematurely (more than 3 weeks early)?` , 
         `Blood in the stool` , `Bowel frequency during the day` , `Bowel frequency during the night` , `3j. Weight loss` ,
         total_reads , filtered_reads , `Yogurt or other foods containing active bacterial cultures (kefir, sauerkraut)` ,
         `Dairy (milk, cream, ice cream, cheese, cream cheese)`,Probiotic , `Red meat (beef, hamburger, pork, lamb)` , 
         `Processed meat (other red or white meat such as lunch meat, ham, salami, bologna` , 
         `Vegetables (salad, tomatoes, onions, greens, carrots, peppers, green beans, etc)` , 
         `White meat (chicken, turkey, etc.)` , `Fish (fish nuggets, breaded fish, fish cakes, salmon, tuna, etc.)`  , 
         `Shellfish (shrimp, lobster, scallops, etc.)`  , Antibiotics,  Chemotherapy , 
         `Immunosuppressants (e.g. oral corticosteroids)` , `6) Have you ever had bowel surgery?` , 
         `In the past 3 months, have you consumed any probiotics (other than yogurt)` , 
         Eggs,`Did you grow up on a farm?`,`Subject has an immune mediated disease (i.e. rheumatoid arthritis, lupus, T1DM):`,
         `Subject is pregnant:` , `Subject has an acute gastrointestinal infection or IBD:` , Weight , 
         `For UC and CD, has the disease classification changed since baseline?` , 
         fecalcal_ng_ml ,  `3j. Weight loss` , `Age at diagnosis`)

fit = aov(`Age at diagnosis` ~ diagnosis, data = pheno.selected)
summary(fit)
table(pheno.selected$diagnosis)
pheno.selected %>% 
  filter(diagnosis != "nonIBD") %>% 
  ggplot() + geom_density(aes(x =`Age at diagnosis` , fill = diagnosis))

pheno.selected %>% 
  filter(diagnosis != "nonIBD") %>% 
  ggplot() + geom_density(aes(x = `Age at diagnosis`)) + facet_wrap(~diagnosis)
# CD is earlier!
length(unique(colnames(dataset)))

# For example in Firmicutes
lactobasillales.idx <- grep("Lactobacillales" , dataset$`#SampleID`)[1]
bacillales.idx <- grep("Bacillales" , dataset$`#SampleID`)[1]
clostridiales.idx <- grep("Clostridiales" , dataset$`#SampleID`)[1]
erysipelotrichales.idx <- grep("Erysipelotrichales" , dataset$`#SampleID`)[1]

subset.data <- dataset[ , c(lactobasillales.idx , bacillales.idx , clostridiales.idx , erysipelotrichales.idx)]


# Normalization is a hot problem in microbiome data
# First I try a simple normlization

library(phyloseq)

data.norm1 = transform_sample_counts(data.phy, function(x){x / sum(x)})

plot_abundance = function(physeq,title = "",
                          Facet = "Order", Color = "Phylum"){
  # Arbitrary subset, based on Phylum, for plotting
  mphyseq = psmelt(physeq)
  mphyseq <- subset(mphyseq, Abundance > 0)
  ggplot(data = mphyseq, mapping = aes_string(x = "sex",y = "Abundance",
                                              color = Color, fill = Color)) +
    geom_violin(fill = NA) +
    geom_point(size = 1, alpha = 0.3,
               position = position_jitter(width = 0.3)) +
    facet_wrap(facets = Facet) + scale_y_log10()+
    theme(legend.position="none")
}

plotBefore = plot_abundance(data.phy,"")
plotAfter = plot_abundance(data.norm1,"")
# Combine each plot into one graphic.
library(gridExtra)
plotBefore
grid.arrange(nrow = 2,  plotBefore, plotAfter)
