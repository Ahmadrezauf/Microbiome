analyzeTaxRank.zeros <- function(dat, idx){
  data.size <- dim(dat)[1] * dim(dat)[2]
  data.zeros <- sum(dat == 0)
  data.nonzeros <- sum(dat != 0)
  
  # print("Number of elements")
  # print(data.size)
  # print("Number of Zeros")
  # print(data.zeros)
  # print("Number of nonzeros")
  # print(data.nonzeros)
  dat.summary <- data.frame(rank = idx , No.elements = data.size , zeros = data.zeros , nonzeros = data.nonzeros)
  
  dat.summary 
  #outputs a data frame in which includes information about the matrix
}


analyzeTaxRank.counts <- function(dat , rank){
  #dat should be a data frame that each row is a rank and each column is a sample
  result <- data.frame(ID = dat$`#SampleID`)
  result$sumOfCounts <- rowSums(dat[2:ncol(dat)] ,na.rm = T)
  result$sumOfVars <- rowVars(as.matrix(dat[2:ncol(dat)]) ,na.rm = T)
  result$iqr <- rowIQRs(as.matrix(dat[2:ncol(dat)]) ,na.rm = T)
  result$Median <- rowMedians(as.matrix(dat[2:ncol(dat)]) ,na.rm = T)
  result$Max <- rowMaxs(as.matrix(dat[2:ncol(dat)]) ,na.rm = T)
  
  result$idx <- rank
  result
  # should add some other functionality
}

taxa.ranks <- c("Kingdom" , "Phylum" , "Class" , "Order" , "Family" , "Genus" , "Species" , "Strain")

createTaxTable <- function(dat , rank){
  # dat is a vector containing specified taxonomic rank
  # But they are separated with "|"
  # Ranks should be equal or higher than two!
  if(!is.null(dim(dat))){
    stop("Should input row names")
  }
  
  require(stringr)
  taxa.names <- dat
  taxa.names %>% 
    str_split(pattern = "\\|") %>% 
    unlist() %>% 
    str_replace(".*_" , "") -> tmp
  result = data_frame()
  
  for(i in 1:(length(tmp)/rank)){
    
    tmpRow <- matrix(nrow = 1 , ncol = rank)
    for( j in 1:rank){
      tmpRow[j] <- tmp[(i-1) * rank + j]
    }
    result <- rbind(result , tmpRow)
  }
  colnames(result) <- taxa.ranks[1:rank]
  rownames(result) <- paste0("OTU" , seq(1 , nrow(result) , by = 1))
  result
  # outputs a data frame that has a column named OTU ID
}
