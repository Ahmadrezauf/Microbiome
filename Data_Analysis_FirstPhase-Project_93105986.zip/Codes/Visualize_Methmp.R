library(readr)

methmp <- read_csv("~/Desktop/RA/Understanding IDB Dataset/hmp2_metadata.csv")
grep("milk", names(methmp))

tmp <- read_tsv("~/Desktop/taxonomic_profiles.tsv")
dim(tmp)

length(intersect(methmp$`External ID` , colnames(tmp)))
# One of them is the first column sample ID !
library(dplyr)
methmp %>% 
  filter(!is.na(Disease_course)) -> tmp1
length(x = intersect(tmp1$`External ID` , colnames(tmp)))
# Oh no, there are no patients that we have their disease course

methmp %>% 
  filter(`Systemic lupus erythematosis` == "Yes") %>% 
  nrow()
# No lopus  

table(methmp$diagnosis)
methmp %>% 
  filter(`External ID` %in% colnames(tmp)) %>% 
  select(diagnosis) %>% 
  table()
methmp %>% 
  filter(diagnosis != "nonIBD") -> tmp1
treatno <- length(intersect(tmp1$`External ID` ,colnames(tmp)))
contno <- ncol(tmp) - 1 - treatno
# How many treat and control do we have in IBD dataset
treatno
contno

table(methmp$data_type)
hist(methmp$`Age at diagnosis` , 100)
table(methmp$`General wellbeing`)
# Most of our samples are doing very well!

table(methmp$`Red meat (beef, hamburger, pork, lamb)`)

table(methmp$`Vegetables (salad, tomatoes, onions, greens, carrots, peppers, green beans, etc)`)
table(methmp$Probiotic)

table(methmp$`Education Level`)
table(methmp$)

