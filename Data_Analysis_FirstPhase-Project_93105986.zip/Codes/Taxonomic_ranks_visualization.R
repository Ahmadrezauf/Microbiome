setwd("~/Desktop/RA/Task 5- Introducing to IBD/")
# I selected metagenomics data!
# HMP2
# While Metagenomics tells us which microbes are present 
# and what genomic potential they have, Metatranscriptomics tells us about their activity
# I use taxonomic profiles that is cleaned and treamed and QCd!

# 16s rRNA is a fingerprint for each bacteria

## Plot krona chart
library(highcharter)
library(readr)
library(matrixStats)
library(gridExtra)
library(ggplot2)
library(pheatmap)
library(corrplot)
library(RColorBrewer)

source("utility.R")
# tab-separated 
metagenome.tax.data <- read_tsv("Data/Metagenomics/taxonomic_profiles.tsv.gz")

methmp <- read_csv("Data/hmp2_metadata.csv")

##### Create tax table and otu table 
library(stringr)
library(dplyr)
metagenome.tax.data$`#SampleID` %>% 
  str_count(pattern = "\\|") %>% hist(main = "Histogram of microbes in different ranks")

metagenome.tax.data %>% 
  filter(str_count(`#SampleID` , "\\|") == 7) -> tmp8
metagenome.tax.data %>% 
  filter(str_count(`#SampleID` , "\\|") == 6) -> tmp7
metagenome.tax.data %>% 
  filter(str_count(`#SampleID` , "\\|") == 5) -> tmp6
metagenome.tax.data %>% 
  filter(str_count(`#SampleID` , "\\|") == 4) -> tmp5
metagenome.tax.data %>% 
  filter(str_count(`#SampleID` , "\\|") == 3) -> tmp4

library(tidyr)
library(rlist)
taxas.analysis <- vector(mode = "list")
taxa.ranks <- c("Kingdom" , "Phylum" , "Class" , "Order" , "Family" , "Genus" , "Species" , "Strain")

### PROBLEM : PASS BY REFERENCE
taxas.analysis[[1]] <- analyzeTaxRank.zeros(tmp4 , 4)
taxas.analysis[[2]] <- analyzeTaxRank.zeros(tmp5 , 5)
taxas.analysis[[3]] <- analyzeTaxRank.zeros(tmp6 , 6)
taxas.analysis[[4]] <- analyzeTaxRank.zeros(tmp7 , 7)
taxas.analysis[[5]] <- analyzeTaxRank.zeros(tmp8 , 8)

taxa.ranks.summary <-  bind_rows(taxas.analysis)

tmp <- gather(taxa.ranks.summary)
tmp$ranks <- rep(taxa.ranks[4:8] , 4)
hchart(tmp , "column" , hcaes(x = key , y = value , group = ranks))
# External ID is a marker 

# A function to summarize some statistics about the data
# This function extracts :
# Sum , Variance , IQR , Median , Max
sum.tmp4 <- analyzeTaxRank.counts(tmp4 , 4)
sum.tmp5 <- analyzeTaxRank.counts(tmp5 , 5)
sum.tmp6 <- analyzeTaxRank.counts(tmp6 , 6)
sum.tmp7 <- analyzeTaxRank.counts(tmp7 , 7)
sum.tmp8 <- analyzeTaxRank.counts(tmp8 , 8)

sum(sum.tmp4$sumOfCounts == 0)
sum(sum.tmp5$sumOfCounts == 0)
sum(sum.tmp6$sumOfCounts == 0)
sum(sum.tmp7$sumOfCounts == 0)
sum(sum.tmp8$sumOfCounts == 0)
# We should pay attention that in tmp7 and tmp8, there are rows that are fully zero
tmp7 <- tmp7[-which(sum.tmp7$sumOfCounts == 0) , ]
tmp8 <- tmp8[-which(sum.tmp8$sumOfCounts == 0) , ]

p1 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = sumOfCounts)) + xlab("Sum of counts") + ylab(taxa.ranks[4])
p2 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = sumOfVars)) + xlab("Variance of counts") + ylab(taxa.ranks[4])

p3 <- ggplot(sum.tmp5) + 
  geom_density(aes(x = sumOfCounts)) + xlab("Sum of counts") + ylab(taxa.ranks[5])
p4 <- ggplot(sum.tmp5) + 
  geom_density(aes(x = sumOfVars)) + xlab("Variance of counts") + ylab(taxa.ranks[5])

p5 <- ggplot(sum.tmp6) + 
  geom_density(aes(x = sumOfCounts)) + xlab("Sum of counts") + ylab(taxa.ranks[6])
p6 <- ggplot(sum.tmp6) + 
  geom_density(aes(x = sumOfVars)) + xlab("Variance of counts") + ylab(taxa.ranks[6])

p7 <- ggplot(sum.tmp7) + 
  geom_density(aes(x = sumOfCounts)) + xlab("Sum of counts") + ylab(taxa.ranks[7]) 
p8 <- ggplot(sum.tmp7) + 
  geom_density(aes(x = sumOfVars)) + xlab("Variance of counts") + ylab(taxa.ranks[7])

p9 <- ggplot(sum.tmp8) + 
  geom_density(aes(x = sumOfCounts)) + xlab("Sum of counts") + ylab(taxa.ranks[8])
p10 <- ggplot(sum.tmp8) + 
  geom_density(aes(x = sumOfVars)) + xlab("Variance of counts") + ylab(taxa.ranks[8])


pdf("./Plots/Sum-Variance.pdf")
grid.arrange(ncol = 2 , p1 , p2 , p3, p4, p5, p6, p7, p8 , p9, p10)
dev.off()

pdf("./Plots/qqplots.pdf")
car::qqPlot(sum.tmp4$sumOfCounts , distribution = "norm")
car::qqPlot(sum.tmp5$sumOfCounts , distribution = "norm")
car::qqPlot(sum.tmp6$sumOfCounts , distribution = "norm")
car::qqPlot(sum.tmp7$sumOfCounts , distribution = "norm")
car::qqPlot(sum.tmp8$sumOfCounts , distribution = "norm")
dev.off()

p1 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = iqr)) + xlab("IQR") + ylab(taxa.ranks[4])
p2 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = Median)) + xlab("Median") + ylab(taxa.ranks[4])
p3 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = Max)) + xlab("Max") + ylab(taxa.ranks[4])

p4 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = iqr)) + xlab("IQR") + ylab(taxa.ranks[5])
p5 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = Median)) + xlab("Median") + ylab(taxa.ranks[5])
p6 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = Max)) + xlab("Max") + ylab(taxa.ranks[5])

p7 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = iqr)) + xlab("IQR") + ylab(taxa.ranks[6])
p8 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = Median)) + xlab("Median") + ylab(taxa.ranks[6])
p9 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = Max)) + xlab("Max") + ylab(taxa.ranks[6])

p10 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = iqr)) + xlab("IQR") + ylab(taxa.ranks[7])
p11 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = Median)) + xlab("Median") + ylab(taxa.ranks[7])
p12 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = Max)) + xlab("Max") + ylab(taxa.ranks[7])

p13 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = iqr)) + xlab("IQR") + ylab(taxa.ranks[8])
p14 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = Median)) + xlab("Median") + ylab(taxa.ranks[8])
p15 <- ggplot(sum.tmp4) + 
  geom_density(aes(x = Max)) + xlab("Max") + ylab(taxa.ranks[8])

pdf("./Plots/IQR-Median-Max.pdf")
grid.arrange(ncol = 3, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15)
dev.off()

pdf("./Plots/Pheatmaps.pdf")
pheatmap(tmp4[,2:ncol(tmp4)])
pheatmap(tmp5[,2:ncol(tmp5)])
pheatmap(tmp6[,2:ncol(tmp6)])
pheatmap(tmp7[,2:ncol(tmp7)])
pheatmap(tmp8[,2:ncol(tmp8)])
dev.off()

t(tmp4[,2:ncol(tmp4)]) %>% 
  cor(method = "spearman" , use = "complete.obs") -> tmp4.cor
t(tmp5[,2:ncol(tmp5)]) %>% 
  cor(method = "spearman" , use = "complete.obs") -> tmp5.cor
t(tmp6[,2:ncol(tmp6)]) %>% 
  cor(method = "spearman" , use = "complete.obs") -> tmp6.cor
t(tmp7[,2:ncol(tmp7)]) %>% 
  cor(method = "spearman" , use = "complete.obs") -> tmp7.cor # Has NA
t(tmp8[,2:ncol(tmp8)]) %>% 
  cor(method = "spearman" , use = "complete.obs") -> tmp8.cor # Has NA

pdf("./Plots/CorrelationHeatmaps.pdf")
corrplot(tmp4.cor , method = "circle", order = "hclust" , addrect = 10 , 
         col = brewer.pal(n = 8, name = "PuOr"), tl.col = "black" , sig.level = 0.4)
corrplot(tmp5.cor , method = "circle", order = "hclust" , addrect = 10 , 
         col = brewer.pal(n = 8, name = "PuOr"), tl.col = "black" , sig.level = 0.4)
corrplot(tmp6.cor , method = "circle", order = "hclust" , addrect = 10 , 
         col = brewer.pal(n = 8, name = "PuOr"), tl.col = "black" , sig.level = 0.4)
corrplot(tmp7.cor , method = "circle", order = "hclust" , addrect = 10 , 
         col = brewer.pal(n = 8, name = "PuOr"), tl.col = "black" , sig.level = 0.4)
corrplot(tmp8.cor , method = "circle", order = "hclust" , addrect = 10 , 
         col = brewer.pal(n = 8, name = "PuOr"), tl.col = "black" , sig.level = 0.4)
dev.off()
